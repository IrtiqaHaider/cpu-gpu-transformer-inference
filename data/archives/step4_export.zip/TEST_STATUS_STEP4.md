# Step 4 — local test scope

The local CPU suite completed **231 passed, 9 CUDA-specific skipped**. This includes the unchanged Step 3 tests and 46 new robustness tests.

Tests cover the fixed ABBA protocol, candidate counts, new-VM and thread gates, safe input extraction, unchanged margin, scoring without reselection, corrupted-trial rejection, cache/throughput accounting, preservation of slow trials, incomplete exports, and a complete analysis path using **explicitly synthetic test fixtures**.

The source Step 3 archive was independently audited: frozen hashes, saved predictions and decisions, all 230 generation trials, and uploaded analysis reproduced. The source archive records 194 passing tests and 20 successful pretrained checks on its T4 runtime. Those are prior results, not new local GPU execution.

**Not executed locally:** pretrained downloads for Step 4, the 26 T4 numerical comparisons, the 260 proposed generation measurements, and interactive Colab upload/download dialogs. Synthetic test fixtures are not benchmark evidence.
