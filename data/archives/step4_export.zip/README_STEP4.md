# Step 4 — frozen-model replication and CPU-thread sensitivity

## Scope

The Step 3 archive completed the prospective workload evaluation. Step 4 is the last planned measurement increment in the five-step research extension; Step 5 packages the report and public artifact.

Step 4 does **not** tune the predictor, change the original 5% + 16 MiB margin, optimize the runtime, or introduce a new model. The engine, timed functions, latency models, memory model and frozen placement choices remain unchanged.

The selected batch-three workloads were chosen **after reviewing Step 3**. Treat this as a targeted replication and sensitivity study, not a new blind workload test or public preregistration.

## Design

Use a **fresh Colab T4 VM**. A different notebook tab or a Python-kernel restart may still use the old VM. Preflight requires a different boot ID from Step 3, and prevents mixing VMs within Step 4. A different boot ID records runtime separation; it does not prove statistical independence or a different physical host.

- Batch 3; prompt lengths 64 and 256; 0/3/6/9/12 GPU blocks: ten settings.
- Batch 1; prompt 128; 0/6/12 GPU blocks: three historical controls.
- FP32, GPT-2 at the original pinned revision, prefix placement, 32 generated tokens.
- Four blocks with thread order **2, 1, 1, 2**; reversed case order for the second block at each thread count.
- Five warmups and five measured repetitions per case per block.
- **260 measured generations**, including 60 control generations. Warmups, numerical checks and prefill calls are not additional generation trials.
- Independent pretrained comparisons for all thirteen cases at both thread counts: **26 checks**, each covering last-position prefill logits and three teacher-forced cached steps.

All predictions and policy decisions are copied from the previous frozen values. The one-thread experiment deliberately challenges a two-thread-calibrated predictor. Report its results separately from two-thread replication, rather than claiming it is an in-distribution test.

## Notebook

1. Write the bundled source and install dependencies. Keep Colab's CUDA-enabled PyTorch.
2. Upload **step3_20260919T202327166768Z_export.zip** only.
3. Run software tests.
4. Audit Step 3 and seal the unchanged predictions and Step 4 protocol.
5. Check the new VM and run both pretrained numerical gates.
6. Collect all four blocks, sequentially.
7. Evaluate thread sensitivity and cross-session replication separately.
8. Export **step4_..._export.zip**, including on a failure.

Do not rerun a measurement block that started. Do not replace slow trials or silently change the guard. Stop on failure and export the partial run. A missing/failed case prevents a complete policy comparison.

## CLI

```bash
python -m offload_research.robustness prepare --step3 /path/to/step3_export.zip --out runs/step4_UNIQUE
python -m offload_research.collect_robustness preflight --out runs/step4_UNIQUE
python -m offload_research.collect_robustness reference --threads 2 --out runs/step4_UNIQUE
python -m offload_research.collect_robustness reference --threads 1 --out runs/step4_UNIQUE
python -m offload_research.collect_robustness collect --block 0 --out runs/step4_UNIQUE
python -m offload_research.collect_robustness collect --block 1 --out runs/step4_UNIQUE
python -m offload_research.collect_robustness collect --block 2 --out runs/step4_UNIQUE
python -m offload_research.collect_robustness collect --block 3 --out runs/step4_UNIQUE
python -m offload_research.robustness analyze --out runs/step4_UNIQUE
python -m offload_research.robustness export --out runs/step4_UNIQUE
```

The uploaded archive hash is intentionally pinned to this checkpoint. Loading a modified/different checkpoint requires an explicitly reviewed protocol change, not bypassing the integrity check.

## Analysis outputs

- `analysis/session_replication.csv`: new two-thread medians / Step 3 medians for matched cases.
- `analysis/thread_comparison.csv`: one-thread / two-thread measurements within the new VM.
- `analysis/block_timing.csv`: per-block medians, IQR/median, maximum/median and a descriptive slow-trial count.
- `analysis/prediction_metrics.csv`: generation/prefill/decode errors, separated by thread count.
- `analysis/memory_metrics.csv`: error over GPU-positive configurations; CPU-only percentage errors excluded.
- `analysis/policy_scores.csv`: frozen choices versus the best measured feasible candidate, separately by thread count.
- `analysis/all_trials.csv`: all measured generations; none removed.
- `step3_exploratory/margin_sensitivity.csv`: counterfactual rescoring of Step 3 using four illustrative margin formulas. This is **post-hoc analysis**, not a tuned or deployed alternative planner. The primary experiment keeps the original margin.

Budgets refer to **peak PyTorch allocated tensor memory**. They are synthetic constraints, not enforced physical capacity, total reserved memory, all GPU processes, or CPU RAM. A zero violation count does not certify future safety.

Whole-case CPU and accessible cgroup snapshots include placement, correctness checks and warmups. They are not a per-trial causal trace. Root counters may cover other processes; unavailable or zero local counters do not exclude ancestor or host-level limits. No limits or affinity settings are changed.

Ten trials per case per thread setting and two within-session blocks do not establish stable p95 or reliable cross-platform confidence intervals. Preserve both sessions separately. Interpret modest differences conservatively.

## Export provenance

The export preserves the original Step 3 ZIP byte-for-byte under `inputs/step3_export.zip`. Its expanded working `parent/` folder is omitted to avoid redundant nested archives. For a later offline audit, restore `parent/` from that ZIP before calling `verify`, then use the included unchanged source snapshot. Do not execute code taken from an untrusted archive.

Old Step 3 README/test-status files describe the previous increment. `README_STEP4.md` and `TEST_STATUS_STEP4.md` describe this increment.

## References

- PyTorch benchmarking (warmup, synchronization, thread sensitivity, variability): https://docs.pytorch.org/tutorials/recipes/recipes/benchmark.html
- Linux cgroup v2 controller scope and counters: https://docs.kernel.org/admin-guide/cgroup-v2.html

These references support methodology, not the numerical measurements in the user's archive.
