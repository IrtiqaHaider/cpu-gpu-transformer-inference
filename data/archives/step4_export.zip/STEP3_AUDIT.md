# Step 3 checkpoint audit and interpretation

Input: `step3_20260919T202327166768Z_export.zip`  
SHA-256: `a24306bcc49770085a586b6b717c3490ce272fd227a4b40e53d14a00dc0b4181`

## Decision

The prospective workload experiment is complete. Proceed to the targeted Step 4 robustness check, not another original full sweep. No inference measurements were run locally during this audit.

## Integrity and coverage

Frozen model/source/protocol hashes passed. The saved predictions and decisions were reproduced from the unchanged models; the analysis JSON was recomputed exactly from the supplied raw files.

The archive records **194 passing software tests** on the user's runtime, and **20 successful pretrained comparisons** (four workload shapes by five placements). Each reference check covers last-position prefill logits and three teacher-forced decode steps, not every generated token. Maximum absolute differences: prefill 0.000114441, cached decode 0.000068665. All recorded argmax comparisons agree on those test inputs; this is not task accuracy.

There are **20 primary configurations, three controls, 46 case/block records, and 230 measured generations**: 200 primary plus 30 control. All 46 records report success. Both blocks belong to one T4 VM; recorded CPU/software comparison fields match calibration. Timing behavior can still change despite matching metadata. Each generation has 31 cached steps, yielding 7,130 raw cached-step observations, which are not independent experimental replicates.

## Prediction results on the new workloads

| Model | Median generation error | Worst generation error |
|---|---:|---:|
| Compute-only | 11.69% | 42.79% |
| Compute + transfers | 11.09% | 42.84% |

Error is absolute percentage difference relative to the per-case median measured generation latency, equally weighting 20 primary cases. It is not token prediction accuracy or a speedup. The small difference between predictors is not established as a reliable improvement.

Memory prediction error over the **16 GPU-containing primary configurations** is **0.69% median, 1.87% worst**. Four CPU-only cases are excluded from percentage error, since their measured GPU allocation is zero. The old JSON field name ends in `gpu_only`, but its implementation actually includes *all* GPU-containing placements, not just all-GPU execution.

Worst generation error occurs at batch 3, prompt 64, CPU-only: predicted 2852.63 ms versus measured median 1997.12 ms. Several batch-three mixed cases are also overpredicted. Do not refit after seeing this and continue to call the same workload set untouched test data.

## Policy results and the safety-margin tradeoff

All three policies select the same placement on all **32 workload/budget pairs**. Their 96 score records are repeated evaluations of four measured workloads, not 96 independent inference experiments. None of the selected plans exceeds the measured peak-allocation budget. Median feasible regret is zero; worst regret is **239.55%**, or **3.3955 times the best measured feasible latency**.

At batch 3, prompt 256, output 32, budget 640 MiB:

| Candidate | Frozen point memory estimate | With original guard | Actual measured peak | Median generation |
|---|---:|---:|---:|---:|
| 9 GPU / 3 CPU | 510.35 MiB | 551.86 MiB | 505.82 MiB | 1091.08 ms |
| 12 GPU / 0 CPU | 614.50 MiB | 661.22 MiB | 619.24 MiB | 321.33 ms |

The all-GPU candidate actually fits, and even its point estimate fits, but the fixed **5% + 16 MiB guard** rejects it. Thus the default guard causes the conservative selection in this example. This does not prove a smaller margin will always be safe. No physical GPU limit was enforced.

## Runtime variability

Matched historical controls (batch 1, prompt 128, output 32) have new/old generation-median ratios of **0.8946 CPU-only**, **0.8953 six/six**, and **1.0318 all-GPU**. CPU-involving controls are about 10.5% faster by this descriptive comparison, while all-GPU is about 3.2% slower. These three controls do not establish the cause or permit universal rescaling.

Two reverse-order blocks in one VM do not establish stable tails or general cross-machine performance. Preserve all raw timings. The results support a scoped prediction/generalization study and a negative policy comparison, not a planner speedup over maximum-GPU placement.

## Step 4 rationale

Replicate batch-three prompt-64/prompt-256 cases (all five placements) and the three historical controls in a new T4 VM. Compare two versus one CPU thread with ABBA ordering and unchanged predictions. This is post-hoc selected robustness testing, not a new blind workload set. Keep the original guard; separately label any margin counterfactual as exploratory.

Step 5 remains the report, reproducible release and academic-CV presentation. A second model and optimized scheduling are optional future studies.

## Method references

- PyTorch benchmark guidance: https://docs.pytorch.org/tutorials/recipes/recipes/benchmark.html
- Linux cgroup v2: https://docs.kernel.org/admin-guide/cgroup-v2.html

Numerical evidence comes from the uploaded ZIP's `frozen/`, `measurement/`, `reference_validation.json`, and `analysis/` records, not from these references.
