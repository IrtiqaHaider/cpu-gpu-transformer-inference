# CPU–GPU heterogeneous inference: experiment report

## Research question

Under a fixed workload and precision, how does static CPU block placement trade
GPU memory for latency, and how much does device-boundary count matter?

## Reproduction record

Record the model ID and resolved SHA, CPU model and thread count, actual GPU,
PyTorch/CUDA versions, package freeze, attention implementation, FP32 precision,
prompt/batch/output dimensions, seeds, warmups, repetitions, and timing scope.
Attach metadata.json and validation.json. State that inputs are unpadded synthetic
IDs and generation is fixed-length, not an EOS-stopped serving workload.

## Correctness

Fill from independent validation, not from an assumption:

| Placement | Prefill max absolute logit error | Cached-chunk error | Top-1 agreement |
|---|---|---|---|
| CPU-only | Pending measured validation | Pending | Pending |
| GPU-only | Pending measured validation | Pending | Pending |
| Contiguous split | Pending measured validation | Pending | Pending |
| Interleaved split | Pending measured validation | Pending | Pending |

Explain numerical tolerances and teacher forcing. Separately state unit-test
counts and any skips. Do not treat skipped CUDA cases as passes.

## Results

Include median and variability, sample count, and raw files for:

1. Prefill latency/input throughput, TTFT, cached decode time per step, and
   end-to-end generated throughput against CPU block fraction.
2. Peak GPU allocation and GPU-resident parameter/cache payload against placement.
3. Same-count prefix/suffix/interleaved comparisons and measured activation bytes.
4. Separate copy-path microbenchmarks (H2D/D2H, pinned/pageable, event/wall timing).

Do not label input-processing throughput as output generation speed. Do not stack
serialized profile timings and uninstrumented latency as if they were one run.

## Interpretation

Report the fastest configuration within a specified GPU-memory budget. Identify
whether that choice changes with batch size or prompt length. Compare predicted
boundary bytes and measured copy behavior. Describe disagreements between the
simple cost model and measurements without inventing an explanation.

## Limitations

Static execution; no asynchronous overlap, weight streaming, compression, or
request scheduler. FP32 eager attention; no fused-attention/FP16 comparison.
Endpoint embeddings/head remain on GPU for mixed plans. Last-position vocabulary
projection only. Dynamic concatenated KV caches. Equal-length unpadded inputs.
One hardware environment; warm-model timing excludes tokenization/loading and
service queueing. Peak PyTorch allocation is not all physical VRAM use.

## Follow-up experiment

Choose one change, hold other variables constant, rerun correctness and compare
against the saved baseline. Suggested first choice: preallocated KV caches or
pinned reusable activation buffers. Describe mechanism, measurement and limits.
